const express = require('express')
const bodyParser = require('body-parser')

const app = express()

app.use(express.static('public'))
app.use(bodyParser.json())

// En enkel användardatabas
const users = []

// registrera en ny användare
app.post('/auth/register', (req, res) => {
    const { username, password } = req.body
    // kontrollera om användaren redan finns
    if (users.some(user => user.username === username)) {
        return res.status(400).send('Användarnamnet är redan taget')
    }
    // skapa en ny användare
    users.push({ username, password })
    res.status(201).send('Användare registrerad')
})

// logga in en användare
app.post('/auth/login', (req, res) => {
    const { username, password } = req.body
    // hitta användaren i användardatabasen
    const user = users.find(user => user.username === username)
    if (!user) {
        return res.status(401).send('Felaktigt användarnamn eller lösenord')
    }
    if (user.password !== password) {
        return res.status(401).send('Felaktigt användarnamn eller lösenord')
    }
    // logga in användaren
    res.status(201).send('Inloggad')
})

const PORT = process.env.PORT || 3000
app.listen(PORT, () => console.log(`Server running on port ${PORT}`))
