document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.querySelector('#loginForm')
    const registerForm = document.querySelector('#registerForm')
    const messageDiv = document.querySelector('#message')

    loginForm.addEventListener('submit', async function(event) {
        event.preventDefault()
        const formData = new FormData(loginForm)
        const responseData = await fetch('/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(Object.fromEntries(formData))
        }).then(response => response.text())

        // clear form
        loginForm.reset()
        showmsg(responseData)
    })

    registerForm.addEventListener('submit', async function(event) {
        event.preventDefault()
        const formData = new FormData(registerForm)
        const responseData = await fetch('/auth/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(Object.fromEntries(formData))
        }).then(response => response.text())

        registerForm.reset()
        showmsg(responseData)
    })

    // arrow func
    const showmsg = txt => {
        document.querySelector('.h').style.display = 'block'
        messageDiv.textContent = txt

        // hide messageDiv after 2 seconds
        setTimeout(() => {
            document.querySelector('.h').style.display = 'none'
        }, 2000)
    }
})
